<?php 
include 'includes/sessions.php';
include 'includes/header-member.php';
?>

<h1>Products</h1>

<p>A list of products would go here.</p>

<?php include 'includes/footer.php'; ?>